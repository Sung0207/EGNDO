function mcal=modelgrav(X,dis,select)
[K,z,x0,theta,q]=pisah(X);
p1 = length(z);
% m=Forwardmodelling(dis,K,z,x0,theta,q);
for jj = 1:p1
    m(:,jj)=Forwardmodelling(dis,K(jj),z(jj),x0(jj),theta(jj),q(jj),select(jj));
end
[m1 n]=size(m);
if n==1
    mcal=m;
else
    mcal=sum(m')';
end