function [F1,F2]=Fscales(i,j,k,uF);
if rand<0.5
    F1=uF(j)+0.1*randn;
    F2=uF(k)+0.1*randn;
else
    F1=uF(i)+0.1*randn;
    F2=uF(i)+0.1*randn;
end
end