function fobj=fmagnetic(X)
global dis mobs select
mcal=modelgrav(X,dis,select);
m1=length(dis);
r1=norm(mcal-mobs);
fobj=r1/sqrt(m1);
% % fobj=r1/norm(mobs);
% r3=norm(mobs+mcal);
% fobj=2*r1/(r1+r3);
% r4=mobs-mcal;mr=(max(mobs)-min(mobs))/2;
% r5=abs(mobs);fobj=mean((r4./(r5+mr)).^2);
end

