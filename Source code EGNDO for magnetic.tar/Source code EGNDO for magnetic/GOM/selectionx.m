function [v1,v2,a,b]=selectionx(x,i,n,fitness)
a=randperm(n,1);b=randperm(n,1);c=randperm(n,1);
while a==i || a==b || c==b || c==a ||c==i ||b==i
    a=randperm(n,1);
    b=randperm(n,1);
    c=randperm(n,1);
end
if fitness(a)<fitness(i)  %Eq. 24
    v1=x(a,:)-x(i,:);  
else 
    v1=x(i,:)-x(a,:);
end
if fitness(b)<fitness(c) %Eq. 25
     v2=x(b,:)-x(c,:);
else 
     v2=x(c,:)-x(b,:);
end 
end