function [K,z,x0,theta,q]=pisah(X);
[m n]=size(X);
nm=fix(n/5);
for ii=1:nm;
    K(ii)=X(ii);
    z(ii)=X(ii+nm);
    x0(ii)=X(ii+2*nm);
    theta(ii)=X(ii+3*nm);
    q(ii)=X(ii+4*nm);
end
end