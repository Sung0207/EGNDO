function newsol=Local_GNDO(i,x,bestSol,mo,d)
u=1/3*(x(i,:)+bestSol+mo); 
deta=sqrt(1/3*((x(i,:)-u).^2+(bestSol-u).^2+(mo-u).^2)); %Eq. 20
vc1=rand(1,d);vc2=rand(1,d);
%Eq. 21 ////////////////////////////////////////////
a = rand;b = rand;
if a<=b
   Z1=sqrt(-1*log(vc2)).*cos(2*pi.*vc1);
   eta = (u+deta.*Z1);
else
   Z2=sqrt(-1*log(vc2)).*cos((2*pi.*vc1)+pi);
   eta = (u+deta.*Z2);
end
newsol = eta;
end
