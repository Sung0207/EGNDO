function Anomaly=Forwardmodelling(dis,K,z,x0,theta,q,select)
if select==1
    Anomaly=Sphere(dis,K,z,x0,theta,q);
elseif select==2
    Anomaly=cylinder(dis,K,z,x0,theta,q);
elseif select==3
    Anomaly=thindyke(dis,K,z,x0,theta,q);
else
    Anomaly=thinsheet(dis,K,z,x0,theta,q);
end
end

function Anomaly=Sphere(dis,K,z,x0,theta,q)
dx=(dis-x0);
Anomaly=K*z^3*(((2*z^2-dx.^2)*sind(theta)-3*z.*dx*cosd(theta))./(dx.^2+z^2).^q);
end
function Anomaly=cylinder(dis,K,z,x0,theta,q)
dx=(dis-x0);
Anomaly=K*(((z^2-dx.^2)*cosd(theta)+2*z.*dx*sind(theta))./(dx.^2+z^2).^q);
end
function Anomaly=thindyke(dis,K,z,x0,theta,q)
dx=(dis-x0);
Anomaly=K*z*((dx*sind(theta)+z*cosd(theta))./(dx.^2+z^2).^q);
end
function Anomaly=thinsheet(dis,K,z,x0,theta,q)
dx=(dis-x0);
Anomaly=K*((z*cosd(theta)-dx*sind(theta))./(dx.^2+z^2).^q);
end
