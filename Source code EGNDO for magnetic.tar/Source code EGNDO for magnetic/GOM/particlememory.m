function [fold,xold,pos,Iout]=particlememory(xnew,xold,dim,f,fold,Itot,pilih)
Inx=(fold<f);
if pilih==1
    Iout = Itot;
else
    if sum(Inx)==0;
        Iout=ones(length(fold),1);
    else
        Iout=Itot(Inx);
    end
end
 Indx=repmat(Inx,1,dim);
 pos=[xnew(Inx,:) f(Inx)];
 xnew=Indx.*xold+~Indx.*xnew;
 f=Inx.*fold+~Inx.*f;
 fold=fitness;xold=xnew;
