function [F1,F2]=Ffactor(i,j,uF)

F1=uF(i)+0.1*trnd(1,1,1);%�?从柯西分布
F2=uF(j)+0.1*trnd(1,1,1);
while F2<=0
      F2=uF(j)+0.1*trnd(1,1,1);
end
while F1<=0
    F1=uF(i)+0.1*trnd(1,1,1);
end
if F1>=1 || F2>=1
    F1=1;
    F2=1;
end
end
