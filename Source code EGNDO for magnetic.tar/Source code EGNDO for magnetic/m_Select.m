function [VarMin,VarMax,nVar,mobs,dis,X,nPop,fun,select] = m_Select(func_flag)
switch func_flag
  case 1
        select=[3];
        Kmin=0;Kmax=1000;
        zmin=33;zmax=102;
        x0min=-50;x0max=50;
        qmin=0.5; qmax=1.5;
        thetamin=-90;thetamax=90;
        VarMin = [Kmin zmin x0min thetamin qmin];
        VarMax = [Kmax zmax x0max thetamax qmax];
        nVar =length(VarMin);
        nPop=10*nVar;
        mobs1=xlsread('Data Magnetik.xlsx',1); % Pima Arizona anomaly 
        mobs=mobs1(:,2);dis=mobs1(:,1);

    case 2
        select=[3 3 3];
        Kmin=[0 0 0];Kmax=[1000 5000 5000];
        zmin=[0 0 0];zmax=[30 200 100];
        x0min=[50 150 200];x0max=[150 250 275];
        qmin=[0.5 0.5 0.5]; qmax=[1.5 1.5 1.5];
        thetamin=[0 0 -90];thetamax=[90 90 90];
        VarMin = [Kmin zmin x0min thetamin qmin];
        VarMax = [Kmax zmax x0max thetamax qmax];
        nVar =length(VarMin);
        nPop=10*nVar;
        mobs1=xlsread('Data Magnetik.xlsx',2); %Beldih mine, Purulia, West Bengal, India/ Mandal 2013 
        mobs=mobs1(:,2);dis=mobs1(:,1);

    case 3
        select=[1 1 1];
        Kmin=[-1000 0 -500];Kmax=[0 500 0];
        zmin=[0 0 0];zmax=[200 500 500];
        x0min=[0 600 800];x0max=[100 1000 1100];
        qmin=[1.2 1.2 1.2]; qmax=[3.6 3.7 3.7];
        thetamin=[0 -90 0];thetamax=[180 90 90];
        VarMin = [Kmin zmin x0min thetamin qmin];
        VarMax = [Kmax zmax x0max thetamax qmax];
        nVar =length(VarMin);
        nPop=10*nVar;
        mobs1=xlsread('Data Magnetik.xlsx',3); %Tangarparha_Odisha anomaly 
        mobs=mobs1(:,2);dis=mobs1(:,1);
    case 4
        select=[4 4];
        mobs1=xlsread('Data Magnetik.xlsx',4); % Hamrawein_anomaly 
        mobs=mobs1(:,2);dis=mobs1(:,1);
        Kmin=[0 0];Kmax=[5e3 5e3];
        zmin=[100 100];zmax=[1500 1000];
        x0min=[3860 13964];x0max=[5371 16113];
        qmin=[0.7 0.7]; qmax=[2.5 2.5];
        thetamin=[-90 -90];thetamax=[90 90];
        VarMin = [Kmin zmin x0min thetamin qmin];
        VarMax = [Kmax zmax x0max thetamax qmax];
        nVar =length(VarMin);
        nPop=10*nVar;
    case 5
        select=[1 2 4];
        Kmin=[5 200 150];Kmax=[20 600 450];
        zmin=[5 3 10];zmax=[20 20 50];
        x0min=[-200 -50 50];x0max=[0 50 200];
        qmin=[1.5 1.5 0.5]; qmax=[3.5 3 1.5];
        thetamin=[-90 0 0];thetamax=[90 90 180];
        VarMin = [Kmin zmin x0min thetamin qmin];
        VarMax = [Kmax zmax x0max thetamax qmax];
        nVar =length(VarMin);
        nPop=10*nVar;
        mobs1=xlsread('Data Magnetik.xlsx',5); %Tangarparha_Odisha anomaly 
        mobs=mobs1(:,2);dis=mobs1(:,1);
    case 6
        select=[1 2 4];
        Kmin=[5 200 150];Kmax=[20 600 450];
        zmin=[5 3 10];zmax=[20 20 50];
        x0min=[-200 -50 50];x0max=[0 50 200];
        qmin=[1.5 1.5 0.5]; qmax=[3.5 3 1.5];
        thetamin=[-90 0 0];thetamax=[90 90 180];
        VarMin = [Kmin zmin x0min thetamin qmin];
        VarMax = [Kmax zmax x0max thetamax qmax];
        nVar =length(VarMin);
        nPop=10*nVar;
        mobs1=xlsread('Data Magnetik.xlsx',5); %Tangarparha_Odisha anomaly 
        mobs=mobs1(:,3);dis=mobs1(:,1);
end
for i=1:nPop
    X(i,:)=VarMin+rand(1,nVar).*(VarMax-VarMin);
end
fun=@fmagnetic;
end

