clc
clear all;close all

%Declarations
% Conflict of interest The authors declare that they have no conflict of interest.
% Ethical approval This article does not contain any studies with humanparticipants or animals performed by any of the authors 

global select dis mobs
path = pwd;
path11=strcat(path,filesep);
addpath(strcat(pwd,filesep,'GOM'));
addpath(strcat(pwd,filesep,'Data'));
% addpath(strcat(pwd,filesep,'SFs'));

Number=4;% the number of models
LoopIter=30;% the number of runs
%the maximum number of function evaluations
% nPop=50;%population sizel
Objbest1=[];Objbest2=[];
[VarMin,VarMax,nVar,mobs,dis,X,nPop,fun,select] =m_Select(Number);%intilize parameters
MaxIt=150;
    for i=1:LoopIter % start task
         [Stat1,BestValue1,xgbest1,xpos1]=GBGNDO(fun,nPop,nVar,VarMin,VarMax,MaxIt,X);
         All1(i).PDM=xpos1;
         All1(i).xgbest=xgbest1;
         All1(i).Stat=Stat1;
         Objbest1=[Objbest1 BestValue1];
         disp(['Iteration ' num2str(i) ': the optimal solution of GBGNDO= ' num2str(BestValue1,15)]);
         [Stat2,BestValue2,xgbest2,xpos2]=GNDO(fun,nPop,nVar,VarMin,VarMax,MaxIt,X);
         All2(i).PDM=xpos2;
         All2(i).xgbest=xgbest2;
         All2(i).Stat=Stat2;
         Objbest2=[Objbest2 BestValue2];
         disp(['Iteration ' num2str(i) ': the optimal solution of GNDO= ' num2str(BestValue2,15)]);
         disp(['======================================================================================='])
    end
mcal=modelgrav(xgbest1,dis,select);
plot(dis,mobs,'rs');
hold on
plot(dis,mcal,'b-')
% ylim([0 350])
cd Hasil
% save PimaArizona_RMSE1.mat 
% save Beldihmine_RMSE1.mat 
 % save Odisha_RMSE1.mat
save Hamrawein_RMSE1.mat

